const translations={
ar:{
brand:"نظام إدارة HSE",brandSub:"السلامة والصحة والبيئة",eyebrow:"HSE MANAGEMENT SYSTEM",welcome:"لوحة تحكم السلامة والصحة المهنية والبيئية",admin:"مسؤول HSE",settings:"الإعدادات",currentProject:"المشروع الحالي",projectName:"مشروع الإنشاءات الرئيسي",quickAction:"إجراء سريع",
"nav.dashboard":"لوحة التحكم","nav.risk":"تقييم المخاطر","nav.inspections":"التفتيشات","nav.incidents":"الحوادث والإصابات","nav.actions":"الإجراءات التصحيحية","nav.permits":"تصاريح العمل","nav.ppe":"معدات الوقاية PPE","nav.training":"التدريب والتوعية","nav.environment":"البيئة والاستدامة","nav.emergency":"الطوارئ","nav.reports":"التقارير",
"hero.kicker":"بيئة عمل أكثر أمانًا","hero.title":"نحو صفر حوادث","hero.text":"تابع أداء السلامة والصحة المهنية والبيئية من مكان واحد.",
"stats.workers":"العاملون","stats.safeDays":"أيام العمل الآمنة","stats.openObs":"الملاحظات المفتوحة","stats.incidents":"الحوادث هذا الشهر",
"chart.title":"مؤشر أداء HSE","chart.sub":"آخر 6 أشهر","months.jan":"يناير","months.feb":"فبراير","months.mar":"مارس","months.apr":"أبريل","months.may":"مايو","months.jun":"يونيو",
"compliance.title":"مؤشرات الالتزام","compliance.sub":"الحالة الحالية","compliance.risk":"تقييم المخاطر","compliance.inspect":"التفتيشات","compliance.training":"التدريب","compliance.ppe":"PPE","overall":"التقييم العام","excellent":"ممتاز",
"recent.title":"آخر الملاحظات","recent.sub":"أحدث الإجراءات المسجلة","viewAll":"عرض الكل","table.issue":"الملاحظة","table.area":"المنطقة","table.status":"الحالة",
"calendar.title":"الأنشطة القادمة","calendar.sub":"الأسبوع الحالي","events.toolbox":"اجتماع Toolbox Talk","events.fire":"تدريب مكافحة الحريق","events.audit":"تفتيش HSE أسبوعي",
"riskPage.title":"تقييم المخاطر","riskPage.text":"إدارة سجل المخاطر وتحديد مستويات الخطورة والإجراءات الوقائية.","addRisk":"إضافة تقييم مخاطر","highRisk":"مخاطر عالية","mediumRisk":"مخاطر متوسطة","lowRisk":"مخاطر منخفضة",
"inspectionPage.title":"التفتيشات والجولات","inspectionPage.text":"جدولة وتنفيذ وتوثيق جولات التفتيش ومتابعة النتائج.","newInspection":"تفتيش جديد","completedInspections":"تفتيشًا منفذًا هذا الشهر",
"incidentPage.title":"الحوادث والإصابات","incidentPage.text":"تسجيل الحوادث والتحقيق فيها وتحليل الأسباب الجذرية ومتابعة الإجراءات.","reportIncident":"تسجيل حادث",
"actionPage.title":"الملاحظات والإجراءات التصحيحية","actionPage.text":"متابعة الملاحظات والإجراءات التصحيحية حتى الإغلاق والتحقق من الفاعلية.","open":"مفتوحة","due":"مستحقة","closed":"مغلقة",
"permitPage.title":"تصاريح العمل","permitPage.text":"إدارة تصاريح الأعمال الساخنة، الأماكن المحصورة، العمل على ارتفاع وغيرها.","newPermit":"تصريح عمل جديد",
"ppePage.text":"متابعة صرف وفحص واستخدام معدات الوقاية الشخصية.","ppeCompliance":"نسبة الالتزام","ppeWorkers":"عامل مسجل","ppeDue":"معدات تحتاج استبدال",
"trainingPage.title":"التدريب والتوعية","trainingPage.text":"خطة التدريب، الحضور، تقييم الكفاءة وسجلات التوعية.","trainingComplete":"نسبة إتمام التدريب",
"environmentPage.title":"البيئة والاستدامة","environmentPage.text":"إدارة النفايات، استهلاك المياه والطاقة، الانبعاثات والجوانب البيئية.","wasteRecycle":"إعادة تدوير النفايات","energy":"استهلاك الطاقة","water":"استهلاك المياه",
"emergencyPage.title":"إدارة الطوارئ","emergencyPage.text":"خطط الطوارئ، نقاط التجمع، التدريبات وسجل الاستجابة.","drill":"تسجيل تمرين طوارئ",
"reportsPage.title":"التقارير والإحصائيات","reportsPage.text":"تقارير شهرية ومؤشرات أداء قابلة للطباعة والتصدير.","printReport":"طباعة التقرير",
"form.title":"العنوان","form.area":"المنطقة","form.notes":"ملاحظات","save":"حفظ"
},
en:{
brand:"HSE Management",brandSub:"Health, Safety & Environment",eyebrow:"HSE MANAGEMENT SYSTEM",welcome:"Health, Safety & Environment Dashboard",admin:"HSE Administrator",settings:"Settings",currentProject:"Current project",projectName:"Main Construction Project",quickAction:"Quick Action",
"nav.dashboard":"Dashboard","nav.risk":"Risk Assessment","nav.inspections":"Inspections","nav.incidents":"Incidents & Injuries","nav.actions":"Corrective Actions","nav.permits":"Work Permits","nav.ppe":"PPE Management","nav.training":"Training & Awareness","nav.environment":"Environment & Sustainability","nav.emergency":"Emergency Management","nav.reports":"Reports",
"hero.kicker":"A safer workplace","hero.title":"Towards Zero Incidents","hero.text":"Monitor occupational safety, health and environmental performance in one place.",
"stats.workers":"Workers","stats.safeDays":"Safe Working Days","stats.openObs":"Open Observations","stats.incidents":"Incidents This Month",
"chart.title":"HSE Performance Index","chart.sub":"Last 6 months","months.jan":"Jan","months.feb":"Feb","months.mar":"Mar","months.apr":"Apr","months.may":"May","months.jun":"Jun",
"compliance.title":"Compliance Indicators","compliance.sub":"Current status","compliance.risk":"Risk Assessment","compliance.inspect":"Inspections","compliance.training":"Training","compliance.ppe":"PPE","overall":"Overall Score","excellent":"Excellent",
"recent.title":"Recent Observations","recent.sub":"Latest recorded actions","viewAll":"View all","table.issue":"Observation","table.area":"Area","table.status":"Status",
"calendar.title":"Upcoming Activities","calendar.sub":"Current week","events.toolbox":"Toolbox Talk","events.fire":"Fire Fighting Training","events.audit":"Weekly HSE Inspection",
"riskPage.title":"Risk Assessment","riskPage.text":"Manage the risk register, risk levels and preventive controls.","addRisk":"Add Risk Assessment","highRisk":"High Risks","mediumRisk":"Medium Risks","lowRisk":"Low Risks",
"inspectionPage.title":"Inspections & Tours","inspectionPage.text":"Schedule, conduct and document inspections and follow up findings.","newInspection":"New Inspection","completedInspections":"inspections completed this month",
"incidentPage.title":"Incidents & Injuries","incidentPage.text":"Record incidents, investigate root causes and track corrective actions.","reportIncident":"Report Incident",
"actionPage.title":"Observations & Corrective Actions","actionPage.text":"Track observations and corrective actions through closure and effectiveness verification.","open":"Open","due":"Due","closed":"Closed",
"permitPage.title":"Work Permits","permitPage.text":"Manage hot work, confined space, work at height and other permits.","newPermit":"New Work Permit",
"ppePage.text":"Track issue, inspection and use of personal protective equipment.","ppeCompliance":"Compliance rate","ppeWorkers":"Registered workers","ppeDue":"Items due for replacement",
"trainingPage.title":"Training & Awareness","trainingPage.text":"Training plans, attendance, competency assessment and awareness records.","trainingComplete":"Training completion rate",
"environmentPage.title":"Environment & Sustainability","environmentPage.text":"Manage waste, water and energy consumption, emissions and environmental aspects.","wasteRecycle":"Waste recycling","energy":"Energy consumption","water":"Water consumption",
"emergencyPage.title":"Emergency Management","emergencyPage.text":"Emergency plans, assembly points, drills and response records.","drill":"Record Emergency Drill",
"reportsPage.title":"Reports & Statistics","reportsPage.text":"Monthly reports and performance indicators ready for printing and export.","printReport":"Print Report",
"form.title":"Title","form.area":"Area","form.notes":"Notes","save":"Save"
}};

let lang=localStorage.getItem("hse-lang")||"ar";
const $=s=>document.querySelector(s);
const $$=s=>document.querySelectorAll(s);

function applyLang(){
  document.documentElement.lang=lang;
  document.documentElement.dir=lang==="ar"?"rtl":"ltr";
  $("#langLabel").textContent=lang==="ar"?"EN":"AR";
  $$("[data-i18n]").forEach(el=>{const k=el.dataset.i18n;if(translations[lang][k])el.childNodes.forEach(n=>{if(n.nodeType===3 && n.textContent.trim())n.textContent=translations[lang][k]});});
  // Labels containing inputs need their first text node updated safely
  $$("label[data-i18n]").forEach(el=>{const k=el.dataset.i18n;if(translations[lang][k] && el.childNodes[0])el.childNodes[0].textContent=translations[lang][k];});
  localStorage.setItem("hse-lang",lang);
}
$("#langBtn").addEventListener("click",()=>{lang=lang==="ar"?"en":"ar";applyLang()});

function showSection(id){
  $$(".page-section").forEach(s=>s.classList.remove("active-section"));
  const sec=document.getElementById(id)||$("#dashboard"); sec.classList.add("active-section");
  $$(".nav-item").forEach(a=>a.classList.toggle("active",a.dataset.section===id));
  const title=sec.querySelector("h2")||$("#pageHeading");
  if(sec.id!=="dashboard" && title) $("#pageHeading").textContent=title.textContent;
  if(sec.id==="dashboard") $("#pageHeading").textContent=translations[lang].welcome;
  history.replaceState(null,"","#"+id);
  $("#sidebar").classList.remove("open");
}
$$(".nav-item,[data-section]").forEach(a=>a.addEventListener("click",e=>{const id=a.dataset.section;if(id){e.preventDefault();showSection(id)}}));

$("#menuBtn").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#notifyBtn").addEventListener("click",()=>alert(lang==="ar"?"لديك 3 تنبيهات جديدة.":"You have 3 new notifications."));

function openModal(type){
  const titles={
    quick:lang==="ar"?"إجراء سريع":"Quick Action",
    risk:lang==="ar"?"إضافة تقييم مخاطر":"Add Risk Assessment",
    inspection:lang==="ar"?"تفتيش جديد":"New Inspection",
    incident:lang==="ar"?"تسجيل حادث":"Report Incident",
    permit:lang==="ar"?"تصريح عمل جديد":"New Work Permit",
    emergency:lang==="ar"?"تسجيل تمرين طوارئ":"Record Emergency Drill"
  };
  $("#modalTitle").textContent=titles[type]||titles.quick;
  $("#modalDesc").textContent=lang==="ar"?"أدخل البيانات المطلوبة ثم اضغط حفظ.":"Enter the required information and click Save.";
  $("#modalBackdrop").classList.add("show");
}
function closeModal(){$("#modalBackdrop").classList.remove("show")}
window.openModal=openModal;window.closeModal=closeModal;
$("#modalBackdrop").addEventListener("click",e=>{if(e.target.id==="modalBackdrop")closeModal()});
$("#quickForm").addEventListener("submit",e=>{
  e.preventDefault();
  alert(lang==="ar"?"تم حفظ البيانات بنجاح.":"Data saved successfully.");
  e.target.reset();closeModal();
});
window.addEventListener("hashchange",()=>showSection(location.hash.slice(1)||"dashboard"));
applyLang();
showSection(location.hash.slice(1)||"dashboard");