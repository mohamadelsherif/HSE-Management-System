# HSE Management Website

Bilingual (Arabic / English) HSE dashboard designed for GitHub Pages.

## Files
- `index.html` — main application
- `style.css` — responsive design
- `script.js` — language switching, navigation and modal forms

## GitHub Pages
1. Create a new GitHub repository.
2. Upload these three files to the repository root.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Choose `main` and `/ (root)`.
6. Save. GitHub will publish the website.

No backend is required for this first version.
